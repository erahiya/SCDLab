/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataaccessobject;

import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author click
 */
public class tables {

    public static void main(String[] args) {
        try {
            //Statement stmt = oon.createStatement(); //for queries 
            String userTable = "create table user(id int AUTO_INCREMENT primary key,name varchar(200),email varchar(200),mobileNumber varchar(10),address varchar(200),password varchar(200),securityQuestion varchar(200),answer varchar(200),status varchar(20), UNIQUE (email))";
            String adminDetails = "insert into user(name,email,mobileNumber, address,password,SecurityQuestion,answer,status)values('Admin','admin@gmail.com','1234567890','rawalpindi','admin','what is your pet name','ABC','true')";
//          String user = "create table user (id int AUTO_INCREMENT primary key,name varchar(200),email varchar(200),mobileNumber varchar(10),password varchar(200), status varchar(20),UNIQUE(email))"; //query
            DbOperations.setDataOrDelete(userTable, "User Table Created");
            DbOperations.setDataOrDelete(adminDetails, "admin Details added");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

}
