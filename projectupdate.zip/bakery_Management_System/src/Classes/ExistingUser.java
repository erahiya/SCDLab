/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author click
 */
public class ExistingUser {

    private String users;
    private newItems items = new newItems();

    public ExistingUser(String users) {
        super();
        this.users = users;
    }

    public void update() {
        System.out.println("Hey ! " + users + "Try a new product " + items.ItemName);

    }

    public void visitBakery(newItems ni) {
        items = ni;
    }

}
