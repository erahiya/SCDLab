/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author click
 */
public class bakery {

    public static void main(String[] args) {
        newItems Bread = new newItems();
        ExistingUser u1 = new ExistingUser("alu ");
        ExistingUser u2 = new ExistingUser("ariba");
        ExistingUser u3 = new ExistingUser("shaggy ");
        ExistingUser u4 = new ExistingUser("elmo ");
        ExistingUser u5 = new ExistingUser("bruno ");
        ExistingUser u6 = new ExistingUser("shadow ");
        ExistingUser u7 = new ExistingUser("Scar ");
        ExistingUser u8 = new ExistingUser("fishy1");
        ExistingUser u9 = new ExistingUser("fishy2");
        ExistingUser u10 = new ExistingUser("billu");

        Bread.Buyer(u1);
        Bread.Buyer(u2);
        Bread.Buyer(u3);
        Bread.Buyer(u4);
        Bread.Buyer(u5);
        Bread.Buyer(u6);
        Bread.Buyer(u7);
        Bread.Buyer(u8);
        Bread.Buyer(u9);
        Bread.Buyer(u10);

        u1.visitBakery(Bread);
        u2.visitBakery(Bread);
        u3.visitBakery(Bread);
        u4.visitBakery(Bread);
        u5.visitBakery(Bread);
        u6.visitBakery(Bread);
        u7.visitBakery(Bread);
        u8.visitBakery(Bread);
        u9.visitBakery(Bread);
        u10.visitBakery(Bread);
        
        
        Bread.ProductAdded("Brownie Bread by Alu :) ");
        
        
        
        
    }

}
