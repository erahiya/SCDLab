/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author click
 */
public class newItems {

    private List<ExistingUser> users = new ArrayList();
    public String ItemName;

    public void Buyer(ExistingUser user) {
        users.add(user);
    }

    public void DeleteItem(ExistingUser user) {
        users.remove(user);
    }

    public void notifyExistingUser() {
        for (ExistingUser user : users) {
            user.update();
        }

    }

    public void ProductAdded(String ItemName) {
        this.ItemName = ItemName;
        notifyExistingUser();

    }

}
