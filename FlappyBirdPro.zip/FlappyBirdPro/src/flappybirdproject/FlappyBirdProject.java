/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybirdproject;

/**
 *
 * @author clicks
 */
public class FlappyBirdProject {

   int currentscore,highscore;

    public FlappyBirdProject(CurrentScore currentScoreDisplay, HighScore highScoreDisplay)
    {
        this.currentscore = currentscore;
        this.highscore = highscore;
    }
    
    private int getlatestscore()
    {
        return 0;
    }
    
   /* public void dataupdate()
    {
        currentscore= getcurrentscore();
        highscore= gethighscore();
        
        
    }*/
    
    
    
}
 class CurrentScore
 {
     private int currentscore;
     
     public void update(int score){
         this.currentscore=currentscore;
         
         display();
         
         
     }
     public void display ()
     {
         System.out.println("\n Current Score Display: " +"currentscore" + currentscore);
         
     }
     
 }
class HighScore
 {
     private int highscore;
     private int currentscore;
     {
     if (this.highscore>=this.currentscore)
     {
      this.highscore=this.currentscore; 
    }
     else 
     {
         System.out.println("   ");
     }
     }
     public void update(int score)
     {
         this.highscore=highscore;
         
         display();   
         
     }
     public void display ()
     {
         System.out.println("\n High Score Display: " +"highscore" + highscore);
         
     }

    public static void main(String[] args) {
        // TODO code application logic here
         HighScore highScoreDisplay= new HighScore();
         CurrentScore  currentScoreDisplay= new CurrentScore();
        
        
    }
    
}
