/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataaccessobject;
import java.sql.*;
/**
 *
 * @author click
 */
public class ConnectionProvider {
    public static Connection getCon(){
       
       try{
           Class.forName("com.mysql.jdbo.Driver");  
           Connection con = DriverManager.getConnection("jdbo:mysql://localhost:3360/javalabbsse","root","1234"); 
          /* try(
                   Connection con = DriverManager.getConnection("jdbo:mysql://localhost:3360/javalabbsse","root",""))  
           {
               Statement stmt = con.createStatement(); 
               stmt.executeUpdate("INSERT into login values ('Rahiya','12345)");   
               stmt.executeUpdate("INSERT into login values ('Rahiya','12345)");  
               ResultSet rs=stmt.executeQuery("select * from login"); 
               while(rs.next()) 
                   System.out.println(rs.getString(1)+"   " +rs.getString(2));
           }*/
          
          return con;
       }
       catch(Exception e)
       {
           
           System.out.println(e);
           return null;
       }
    }
}

    
    

