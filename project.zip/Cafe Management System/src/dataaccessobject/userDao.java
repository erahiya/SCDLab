/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataaccessobject;
import model.User;
/**
 *
 * @author click
 */
public class userDao {
    
    public static void save(User user){
    String query = "insert into user(name,email,mobileNumber,address,password,status)values('"+user.getName()+"','"+user.getEmail()+"','"+user.getMobileNumber()+"','"+user.getAddress()+"','"+user.getPassword()+"','false')" ;                                 
   
    DbOperations.setDataOrDelete(query, "registered succesfully");
    }
}
