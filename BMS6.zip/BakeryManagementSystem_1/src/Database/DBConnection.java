/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author clicks
 */
public class DBConnection {
    public static Connection getCon() {
        // TODO code application logic here
       try{
          
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3308/bms","root","");
                return conn;
            }
        }
        catch(Exception e)
        {
            return null;
        }
    
    
}
}
