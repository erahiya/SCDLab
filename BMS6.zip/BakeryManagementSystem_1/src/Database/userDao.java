/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//all queries related to user
package Database;

import Classes.User;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
//import model.User;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author click
 */
public class userDao {

    public static void save(User user) {
        String query = "insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status)values('" + user.getName() + "','" + user.getEmail() + "','" + user.getMobileNumber() + "','" + user.getAddress() + "','" + user.getPassword() + "','" + user.getSecurityQuestion() + "','" + user.getAnswer() + "','false')";

        DbOperations.setDataOrDelete(query, "registered succesfully");
    }

    public static User login(String email, String password) {

        User user = null;

        try {

            ResultSet rs = DbOperations.getData("select * from user where email='" + email + "'and password=  '" + password + "'");
            while (rs.next()) {
                user = new User();
                user.setStatus(rs.getString("status"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return user;

    }

    public static User getSecurityQuestion(String email) {

        User user = null;
        try {
            ResultSet rs = DbOperations.getData("select * from user where email='" + email + "'  '");
            while (rs.next()) {
                user = new User();
                user.setSecurityQuestion(rs.getString("security question"));
                user.setAnswer(rs.getString("Answer"));
            }
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
        return user;
    }

    public static void update(String email, String newPassword) {
        String query = "update user set password = '" + newPassword + "'where email ='" + email + "' '";

        DbOperations.setDataOrDelete(query, "password Changed Successfully");

    }

    public static void changePassword(String email, String oldPassword, String newPassword) {
        try {
            ResultSet rs = DbOperations.getData("select * from user where email='" + email + "'and password='" + oldPassword + "'");

            if (rs.next()) {//calling update method
                update(email, newPassword);
            } else {
                JOptionPane.showMessageDialog(null, "Old password is wrong");

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, email);
        }
    }

    public static ArrayList<User> Records() {
        ArrayList<User> arrayList = new ArrayList<>();
        try {
            ResultSet rs = DbOperations.getData("select * from user");
            while (rs.next()) {
                User u = new User();
                u.setName(rs.getString("name"));
                arrayList.add(u);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
        return arrayList;
    }
}
