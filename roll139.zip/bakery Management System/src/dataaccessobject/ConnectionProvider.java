/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataaccessobject;
import java.sql.*;
import java.sql.DriverManager;
/**
 *
 * @author click
 */
public class ConnectionProvider {
    
    public static Connection getCon(){
                try{
          //jdbc:mysql://localhost:3306/bms
            {
               Class.forName("com.mysql.cj.jdbc.Driver");
               Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bms","root","root");
               //Statement stmt = conn.createStatement(); 
              // stmt.executeUpdate("INSERT into login values ('Rahiya','12345)");   
               //stmt.executeUpdate("INSERT into login values ('Areeba','54321)");  
               //ResultSet rs=stmt.executeQuery("select * from login"); 
               //while(rs.next()) 
                 //  System.out.println(rs.getString(1)+"   " +rs.getString(2));
           
               return conn;
            }
        }
        catch(Exception e)
        {
            return null;
        }


    }
}
    

